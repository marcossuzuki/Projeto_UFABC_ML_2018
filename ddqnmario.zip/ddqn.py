# -*- coding: utf-8 -*-
import random
#import gym
import numpy as np
from collections import deque
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam
from keras import backend as K

import sys
from rle_python_interface.rle_python_interface import RLEInterface
#from numpy.random import uniform, choice, random

import time
from rominfo import *
from utils import *
radius = 6

def getReward(reward, gameOver, action, dx):
  R = 0 
  
  # +0.5 for stomping enemies or getting itens/coins
  if reward > 0 and not gameOver:
    R += 0.3*np.log(reward)
 
  # incentiva andar pra direita
  if action == 128 and dx > 0:
    R += 0.5
  # e pular correndo
  elif action == 130 and dx > 0:
    R += 0.5

  if gameOver:
    R  -= 2.0
  else:
    R  += 0.1 
    
  return R

EPISODES = 1000


class DQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.gamma = 0.95    # discount rate
        self.epsilon = 0.07#1.0  # exploration rate
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.9999
        self.learning_rate = 0.101
        self.model = self._build_model()
        self.target_model = self._build_model()
        self.update_target_model()

    def _huber_loss(self, target, prediction):
        # sqrt(1+error^2)-1
        error = prediction - target
        return K.mean(K.sqrt(1+K.square(error))-1, axis=-1)

    def _build_model(self):
        # Neural Net for Deep-Q learning Model
        model = Sequential()
        model.add(Dense(100, input_dim=self.state_size, activation='relu'))
        model.add(Dense(24, activation='relu'))
        model.add(Dense(self.action_size, activation='linear'))
        model.compile(loss=self._huber_loss,
                      optimizer=Adam(lr=self.learning_rate))
        return model

    def update_target_model(self):
        # copy weights from model to target_model
        self.target_model.set_weights(self.model.get_weights())

    def remember(self, state, action, reward, next_state, gameOver):
        self.memory.append((state, action, reward, next_state, gameOver))

    def act(self, state):
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        act_values = self.model.predict(state)
        return np.argmax(act_values[0])  # returns action

    def replay(self, batch_size):
        minibatch = random.sample(self.memory, batch_size)
        for state, action, reward, next_state, gameOver in minibatch:
            target = self.model.predict(state)
            if not gameOver:
                target[0][action] = reward
            else:
                a = self.model.predict(next_state)[0]
                t = self.target_model.predict(next_state)[0]
                target[0][action] = reward + self.gamma * t[np.argmax(a)]
            self.model.fit(state, target, epochs=1, verbose=0)
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

    def load(self, name):
        self.model.load_weights(name)

    def save(self, name):
        self.model.save_weights(name)


if __name__ == "__main__":
    rle = loadInterface(True)
    Q, ep, maxActions = getStoredQ()

    total_reward, total_my_reward = 0, 0
    state, x, y = getState(rle.getRAM(), radius)
    randomOrnew = np.random.random()
    it = 0
    history = []
  
    state_size = 171#len(state)/2+2
    action_size = 6#len(actions_list)
    agent = DQNAgent(state_size, action_size)
    agent.load("./save/cartpole-ddqn.h5")
    batch_size = 32
    salvo = False
    for e in range(EPISODES):
        #rle.saveState()
        state, x, y = getState(rle.getRAM(), radius)
        state += ','+str(x)+','+str(y)
        state=state.split(',')
        state = np.reshape(np.array(state), [1, state_size])
        total_my_reward = 0 
        
        while not rle.game_over():
            #env.render()
            a = agent.act(state)
            action = actions_list[a]
            #env.step(action)
            reward = performAction(action, rle)
            
            next_state, xn, yn = getState(rle.getRAM(), radius)
            # contabiliza os ganhos
            R = getReward(reward, rle.game_over(), action, xn-x)
            x = xn
            
            #if x>170 and not salvo:
               #rle.saveState()
               #salvo = True
            total_reward += reward
            total_my_reward += R*100.0+reward
            
            #if rle.game_over():
            #    R = -1.0*100.0
            reward = a if not rle.game_over() else -10
            next_state += ','+str(xn)+','+str(yn)
            next_state = next_state.split(',')
            next_state = np.reshape(np.array(next_state), [1, state_size])
            agent.remember(state, a, reward, next_state, rle.game_over())
            state = next_state
            
            agent.update_target_model()
            #print("episode: {}/{}, score: {}, e: {:.2}, x{}"
            #          .format(e, EPISODES, total_my_reward, agent.epsilon, x))
            '''if done:
                agent.update_target_model()
                print("episode: {}/{}, score: {}, e: {:.2}"
                      .format(e, EPISODES, time, agent.epsilon))
                break'''
            if len(agent.memory) > batch_size:
                agent.replay(batch_size)
        if e % 1 == 0:
            agent.save("./save/cartpole-ddqn.h5")
        
        print("episode: {}/{}, score: {}, e: {:.2}, x{}"
                  .format(e, EPISODES, total_my_reward, agent.epsilon, x))
        #rle.loadState()
        rle = loadInterface(True)
